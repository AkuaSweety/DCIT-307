/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package ServiceObjects;

import DataObjects.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
import server.Configuration;
/**
 *
 * @author SOA-NETBOOK
 */
public class AdminService {
    
	Connection con = null;
        String[] config = new Configuration().configDB();
	String url = config[2];
	String driver =config[3];
	String user =config[0];
	String pass =config[1];
        
	public boolean InsertAdminAcc(Admin admin){
		boolean insert=true;
		try{
		Class.forName(driver).newInstance();
		con = DriverManager.getConnection(url, user, pass);
			try{
				Statement st = con.createStatement();
                                String sqlState = String.format("INSERT INTO AdminAcc (username,password,status,Privilege) VALUES ('%s','%s','%s',%d)",admin.getUsername(),admin.getPassword(),admin.getStatus(),admin.getPrivilege());
				st.executeUpdate(sqlState);
				con.close();
			}
			catch(SQLException s){
			insert=false;
			}
		}
		catch(Exception e){
			insert=false;
		}
		return insert;
	}
        
        public boolean InsertAdminDetails(Admin admin){
		boolean insert=true;
		try{
		Class.forName(driver).newInstance();
		con = DriverManager.getConnection(url, user, pass);
			try{
				Statement st = con.createStatement();
                                String sqlState = String.format("INSERT INTO AdminDetails (idAdminDetails,Surname,OtherNames,Contact,Address,Relative,RelativeContact,username,CompanyName) VALUES (%d,'%s','%s','%s','%s','%s','%s','%s','%s')",admin.getIdAdminDetails(),admin.getSurname(),admin.getOtherNames(),admin.getContact(),admin.getAddress(),admin.getRelative(),admin.getRelativeContact(),admin.getUsername(),admin.getCompanyName());
				st.executeUpdate(sqlState);
				con.close();
			}
			catch(SQLException s){
			insert=false;
			}
		}
		catch(Exception e){
			insert=false;
		}
		return insert;
	}
        
        
	public boolean UpdateAdminAcc(Admin admin){
		boolean update=true;
		try{
			Class.forName(driver).newInstance();
			con = DriverManager.getConnection(url, user, pass);
			try{
				Statement st = con.createStatement();
				String sqlState = String.format("UPDATE AdminAcc SET username='%s',password='%s',status='%s' Privilege=%d WHERE username='%s'",admin.getUsername(),admin.getPassword(),admin.getStatus(),admin.getPrivilege(),admin.getUsername());
				st.executeUpdate(sqlState);
				con.close();
			}
			catch(SQLException s){
				update=false;
			}
		}
		catch(Exception e){
			update=false;
		}
		return update;
	}
        
        
	public boolean UpdateAdminDetails(Admin admin){
		boolean update=true;
		try{
			Class.forName(driver).newInstance();
			con = DriverManager.getConnection(url, user, pass);
			try{
				Statement st = con.createStatement();
				String sqlState = String.format("UPDATE AdminDetails SET idAdminDetails=%d,Surname='%s',OtherNames='%s',Contact='%s',Address='%s',Relative='%s',RelativeContact='%s',CompanyName='%s',username='%s' WHERE username='%s'",admin.getIdAdminDetails(),admin.getSurname(),admin.getOtherNames(),admin.getContact(),admin.getAddress(),admin.getRelative(),admin.getRelativeContact(),admin.getCompanyName(),admin.getUsername(),admin.getUsername());
				st.executeUpdate(sqlState);
				con.close();
			}
			catch(SQLException s){
				update=false;
			}
		}
		catch(Exception e){
			update=false;
		}
		return update;
	}
        
        
        
	public boolean DeleteAdmin(Admin admin){
		boolean delete=true;
		try{
			Class.forName(driver).newInstance();
			con = DriverManager.getConnection(url, user, pass);
			try{
				Statement st = con.createStatement();
				String sqlState = String.format("DELETE FROM AdminAcc WHERE username='%s'",admin.getUsername());
				st.execute(sqlState);
				con.close();
			}
			catch(SQLException s){
				delete=false;
			}
		}
		catch(Exception e){
			delete=false;
		}
		return delete;
	}

	public Vector<Admin> getAllAdminAcc(){
		Vector<Admin> data = new Vector<Admin>();
		try{
			Class.forName(driver);
			con = DriverManager.getConnection(url, user, pass);
			try{
				Statement st = con.createStatement();
				ResultSet result = st.executeQuery("SELECT * FROM AdminAcc");
				while(result.next())
				{
					Admin admin = new Admin();
					admin.setUsername(result.getString(1));
					admin.setPassword(result.getString(2));
					admin.setStatus(result.getString(3));
                                        admin.setPrivilege(result.getInt(4));
					data.add(admin);
				}
				con.close();
			}
			catch(SQLException s){
				System.out.println(s.getMessage());
			}
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return data;
	}

        
        
	public Vector<Admin> getAllAdminDetails(){
		Vector<Admin> data = new Vector<Admin>();
		try{
			Class.forName(driver);
			con = DriverManager.getConnection(url, user, pass);
			try{
				Statement st = con.createStatement();
				ResultSet result = st.executeQuery("SELECT * FROM AdminDetails");
				while(result.next())
				{
					Admin admin = new Admin();
					admin.setIdAdminDetails(result.getInt(1));
					admin.setSurname(result.getString(2));
					admin.setOtherNames(result.getString(3));
                                        admin.setContact(result.getString(4));
                                        admin.setAddress(result.getString(5));
					admin.setRelative(result.getString(6));
                                        admin.setRelativeContact(result.getString(7));
                                        admin.setCompanyName(result.getString(8));
                                        admin.setUsername(result.getString(9));
					data.add(admin);
                                       
				}
				con.close();
			}
			catch(SQLException s){
				System.out.println(s.getMessage());
			}
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return data;
	}

        
        
	public Vector<Admin> getByIDAdminAcc(Admin username){
		Vector<Admin> data = new Vector<Admin>();
		try{
			Class.forName(driver);
			con = DriverManager.getConnection(url, user, pass);
			try{
				Statement st = con.createStatement();
				ResultSet result = st.executeQuery("SELECT * FROM AdminAcc WHERE username ="+username.getUsername());
				while(result.next())
				{
					Admin admin = new Admin();
					admin.setUsername(result.getString(1));
					admin.setPassword(result.getString(2));
					admin.setStatus(result.getString(3));
                                        admin.setPrivilege(result.getInt(4));
					data.add(admin);
				}
				con.close();
			}
			catch(SQLException s){
				System.out.println(s.getMessage());
			}
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return data;
	}
        
        
        public Vector<Admin> getByIDAdminDetails(Admin username){
		Vector<Admin> data = new Vector<Admin>();
		try{
			Class.forName(driver);
			con = DriverManager.getConnection(url, user, pass);
			try{
				Statement st = con.createStatement();
				ResultSet result = st.executeQuery("SELECT * FROM AdminDetails WHERE username ="+username.getUsername());
				while(result.next())
				{
					Admin admin = new Admin();
					admin.setIdAdminDetails(result.getInt(1));
					admin.setSurname(result.getString(2));
					admin.setOtherNames(result.getString(3));
                                        admin.setContact(result.getString(4));
                                        admin.setAddress(result.getString(5));
					admin.setRelative(result.getString(6));
                                        admin.setRelativeContact(result.getString(7));
                                        admin.setCompanyName(result.getString(8));
                                        admin.setUsername(result.getString(9));
					data.add(admin);
                                       
				}
				con.close();
			}
			catch(SQLException s){
				System.out.println(s.getMessage());
			}
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return data;
	}

}
