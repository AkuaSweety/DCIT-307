package server;

import java.io.*;

/**
 *
 *This class writes information into the database
 *
 *This provides the information on the developers of the software.
DCIT307 MINI-PROJECT DISTANCE EDUCATION FIRST SEMESTER 2023 
* is project was done by one student 
* Ruth Mawutor Konotey 10913771
 */



public class WriteToDB {

    File userDirectory;
	FileWriter userPasswordOut;

    /**
     * Constructor of WriteFile
     */
    public WriteToDB(){}


/**
 * this is the method that writes the user data into the file. This method is private and cannot be called by any other class
 * @param fileName is the file name to write message into
 * @param msg is the message that is written into the file
 */
    private void write(String fileName,String msg){

		try{
			/**
             * Make Directory 
             */
			userDirectory = new File("User Directory/");
			userDirectory.mkdirs();

			/**
             * Write Password
             */
			userPasswordOut = new FileWriter("User Directory/"+fileName);
			userPasswordOut.write(msg+"\n");
			userPasswordOut.flush();
			userPasswordOut.close();
		}catch(Exception e){}       
    }

}
