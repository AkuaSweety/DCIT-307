package server;


import java.net.*;
import java.io.*;
import java.util.*;
/**
 *
 *This class handles the client using thread. It is called by the ListenServer class.
 *
 * @author Suleman Abdul-Razak
 * @author OPPONG SAMUEL GYAN
 */
class HandleServer extends Thread  {

Server source;
Socket connection;
ReadFromDB check;

InputStream inStream;
DataInputStream inDataStream;
OutputStream outStream;
DataOutputStream outDataStream;

private String receive, userName,userPassword,purpose,time;
//parameters to check response of server
private static int msgID,status;
private String  senderNumber,message;

StringTokenizer separate;


/**
 * 
 *  HandleServer constructor
 */

    HandleServer ( Socket socket, Server s)  {

        super ();
        connection =  socket;
        source =  s;

    }  // end constructor

// **************  run

    @Override
    @SuppressWarnings("empty-statement")
    public void run  ()  {

        String stringIn, stringOut;
        boolean again = true;

        InetAddress inet = connection.getInetAddress ();
        String origin = inet.getHostName ();
        int originport = connection.getPort ();

        ServerInterface.area.append( "Adding Client from IP Address: "+origin+" on Port: "+originport+"\n\n" );

//reads message from client
        try  {

            outStream = connection.getOutputStream ();
            outDataStream = new DataOutputStream ( outStream );
            inStream = connection.getInputStream ();
            inDataStream = new DataInputStream ( inStream );

           //loop which is always active to read client messages
            while ( true )  {

                receive = inDataStream.readUTF ();
                
                try{
                    
                
                   
                    
                separate = new StringTokenizer(receive,":-:");
                //while(separate.hasMoreTokens()){

            msgID=Integer.parseInt(separate.nextToken(":-:"));
            senderNumber=separate.nextToken(":-:");
            message=separate.nextToken(":-:");
            status=Integer.parseInt(separate.nextToken(":-:"));
            
            ServerInterface.area.append("\n\nReceived message from client: ");
            ServerInterface.area.append("\nSender Number: "+senderNumber+"\tMessage: "+message);
      
            separate = new StringTokenizer(message," ");
            int i=0;
            
            String bill="electricity bill "; 
            String[] content=new String[4];// = null; 
            
            int tokens=separate.countTokens();
            //message separation
            while(separate.hasMoreElements()){
       
                /*if(content[0].equals(null)){
                    //write wrong message format error
                    break; }*/
               // else{
                content[i]=separate.nextToken(" ");//nextToken(" ");
            i++;
            }//}
            
                 if(content[0].toUpperCase().toString().equals("LB")){
                  bill="electricity bill";
                  
                  
                  }
                  if(content[0].toUpperCase().toString().equals("WB")){
                  //perform telephone bill transaction
                  bill="water bill";
                  
                  }
                  if(content[0].toUpperCase().toString().equals("TB")){
                  //perform water bill transaction
                  bill="telephone bill";
                  
                  }
            
            //outDataStream.writeUTF (msgID +":-:"+ senderNumber+":-:"+"This is for testing");
              //condition to select the purpose of the message from client
                 
            
            if(content[0].equals(null)){
                    //write wrong message format error
                    
            //String error="Message format error, please send the correct format. Thank you";
                   outDataStream.writeUTF (msgID +":-:"+ senderNumber+":-:"+"Why on earth would you send an empty message. Feel happy to use the system");
                   
            
            }
            
             else if(content[0].toLowerCase().toString().equals("r")){    //perform request
                //check=new ReadFromDB();
                //message=check.authenticate(userName, userPassword);
                  String keyword=content[1];
                  String ID=content[2];
                  String month=content[3];
                  
                  if(content[1].toUpperCase().toString().equals("LB")){
                  keyword="electricity bill";
                  
                  
                  }
                  else if(content[1].toUpperCase().toString().equals("WB")){
                  //perform telephone bill transaction
                  keyword="water bill";
                  
                  }
                  else if(content[1].toUpperCase().toString().equals("TB")){
                  //perform water bill transaction
                  keyword="telephone bill";
                  
                  }
                  
                  String response=new PerformRequest().performRequest(keyword,ID,month);
                  outDataStream.writeUTF (msgID +":-:"+ senderNumber+":-:"+"Successful, Your "+keyword+" is GHC40");
                  ServerInterface.area.append("\n\nsent message"+msgID +":-:"+ senderNumber+":-:"+"Successful, Your "+keyword+" is GHC40");
                  
                  /*if(keyword.equals("lb")){
                  //perform light bill transaction
                  
                  
                  }
                  else if(keyword.equals("tb")){
                  //perform telephone bill transaction
                  }
                  else if(keyword.equals("wb")){
                  //perform water bill transaction
                  }*/
                  
                  
                
                
                   }

              else { //perform transaction
                   //new WriteToDB(userName,userPassword,time,"0");
                   
                
                if(tokens==3){
                       //pay personal bills
                       ServerInterface.area.append("\n\nsent message"+msgID +":-:"+ senderNumber+":-:"+"Successful, an amount of GHC"+ content[1].toString()+" have been paid as "+bill);
                   
                       outDataStream.writeUTF (msgID +":-:"+ senderNumber+":-:"+"Successful, an amount of GHC"+ content[1].toString()+" have been paid as "+bill);
                    
                   }
                   else if (tokens==4){
                       //pay others bills
                       ServerInterface.area.append(msgID +":-:"+ senderNumber+":-:"+"Successful, an amount of GHC"+ content[1].toString()+" have been paid as "+bill+" for customer ID "+content[1]);
                   
                       outDataStream.writeUTF (msgID +":-:"+ senderNumber+":-:"+"Successful, an amount of GHC"+ content[1].toString()+" have been paid as "+bill+" for customer ID "+content[1]);
                   
                   }
                   else{
                       //error for wrong format of message
                       String error="Message format error, please send the correct format. Thank you";
                   outDataStream.writeUTF (msgID +":-:"+ senderNumber+":-:"+error);
                   
                   }
                    
                   }

            } 
                
                
                catch(NoSuchElementException e){}

            }  // end while

        }  // end try

        catch ( EOFException except ) {
            ServerInterface.area.append("Connection closed by Client on Port \n\n"+originport );


            /*try  {
            connection.close ();
            return;
            }
            catch ( IOException e )  {
            e.printStackTrace ();
            return;
            }*/// end IOException

         }  // end catch EOFException

        catch(SocketException e){}

         catch ( IOException e )  {
            ServerInterface.area.append("Port "+originport + " connection closed abormally\n" );
            e.printStackTrace ();
            return;
         }  // end catch IOException
    }  // end run


}  // end HandleServer
