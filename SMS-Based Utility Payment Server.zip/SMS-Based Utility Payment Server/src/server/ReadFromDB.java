package server;


import java.io.*;
import java.util.*;

/**
 *
 *This class reads from the database
 *
 *This provides the information on the developers of the software.
DCIT307 MINI-PROJECT DISTANCE EDUCATION FIRST SEMESTER 2023 
* is project was done by one student 
* Ruth Mawutor Konotey 10913771
 */



public class ReadFromDB {

File checkFile;
StringTokenizer separate;

private String userName,userPassword,time,status;

/**
 * Constructor of ReadFromDB
 */

public ReadFromDB(){}



public String authenticate(String fileName,String pass){
    checkFile=new File("User Directory/"+fileName);
    
  if(checkFile.exists()){
      		try{
     			FileReader read=new FileReader(checkFile);
      			BufferedReader buffreader=new BufferedReader(read);
                String inFile=buffreader.readLine();

                 separate = new StringTokenizer(inFile,"+");
               // while(separate.hasMoreTokens()){
                 
                    userName=separate.nextToken("+");
                   userPassword=separate.nextToken("+");
                   time=separate.nextToken("+");
                   status=separate.nextToken("+");



   	  			buffreader.close();
      		}catch(Exception e){
    	    }
/**
 * Conditions for correct or wrong user name and password
 */
            if(fileName.equals(userName) && pass.equals(userPassword) && status.equals("0"))
            {}

            else if (!fileName.equals(userName)){
                return "0+0+0+0";
            }

            else if (!pass.equals(userPassword)){
                return "1+0+0+0";
            }
            else if (!status.equals("0")){
                return "1+1+1+0";
            }

            else
            { return "1+1+0+0"; }
	    }
           else
           {return "0+0+0+0"; }
   
    return null;
    
}
}