/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package server;

/**
 *
 *This provides the information on the developers of the software.
DCIT307 MINI-PROJECT DISTANCE EDUCATION FIRST SEMESTER 2023 
* is project was done by one student 
* Ruth Mawutor Konotey 10913771
 */
class PerformRequest {

    public PerformRequest() {
    }

    String performRequest(String keyword, String ID, String month) {
      
        String response=null;
        
        
        return response; 
    }

}
