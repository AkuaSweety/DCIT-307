package server;


import java.net.*;

/**
 *
 *This class uses thread to handle client and give the client to the HandleServer Class.
 *
 *This provides the information on the developers of the software.
DCIT307 MINI-PROJECT DISTANCE EDUCATION FIRST SEMESTER 2023 
* is project was done by one student 
* Ruth Mawutor Konotey 10913771
 */

class ListenServer extends Thread  {



Server source;
ServerSocket listenSocket;

Socket connection;
HandleServer handle;
boolean again = true;
String host;


// **************  ListenServer constructor

    ListenServer ( Server s)  {

        super ();

        source = (Server ) s;

    }  // end constructor


// **************  run

    public void run  ()  {

    try {
        InetAddress here = InetAddress.getLocalHost ();
        host = here.getHostName ();
    }
    catch (UnknownHostException e) {}

        try  {

            listenSocket = new ServerSocket(Server.port);

            ServerInterface.area.append("Server started:\nlistening on IP Address: " +host+" port " + Server.port + "\n\n" );
//make the listening always active
            while ( true )  {

                connection = listenSocket.accept();
                HandleServer handleServer = new HandleServer ( connection, source );
                handleServer.start ();
            }  // end while

    }  catch ( Exception e )  {
        e.printStackTrace ();
        ServerInterface.area.append("Error in opening ServerSocket\n" );
       // System.exit ( 1 );
    }  // end catch


}  // end run


}  // end ListenServer
