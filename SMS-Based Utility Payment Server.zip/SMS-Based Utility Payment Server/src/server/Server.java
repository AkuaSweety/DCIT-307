package server;


import java.awt.event.*;
import java.io.*;
import javax.swing.*;


/** This is the Server class which calls all other classes and serves as the center class upon which all the other classes
 * are called on. It implements ActionListener interface class. For the first time the application is
 * started on a computer, it checks for the existence of a file called ip in ipCheck folder. If the folder does not exist,
 * it request for a port number to which all clients can be connected and served. This is a check for first start of application.
 * If the port number is typed, it writes it to the file which it can always read from to avoid requesting for port number again.
 *
 * <p>
 * <b>SERVER APPLICATION</b><br>
 * The server application interface is very user friendly to serve the administrator. It has a tool bar with buttons for easy access to
 * the application functions like <b>View the activities of the server <b>Change Port Number
 * Text Area and Exit Server on the File Menu.</b> Also <b>How to Use SUPS and About SUPS on the Help Menu</b>. Every activity of
 * the server is displayed on the <b>Text Area</b>  When the server receives a connection from a Client,
 *  it uses <b>Thread</b> to handle the Client and assign a port number to the Client. 
 * <br><br>FUNCTIONS<br>
* <br><b>Change Port Number</b><br>
 * This allows the user to change the port number the server is serving clients
 * <br><b>Clear Text Area </b><br>
 * This allows the user to clear the text area.
 * <br><b>Exit Server</b><br>
 * This exits the server is clicked.
 * <br><b>How to Use SUPS?</b><br>
 * This pops up a help menu that that shows the user how to use the software.
 * <br><b>About</b><br>
 *This provides the information on the developers of the software.
 *
 * <br><br>
 * Login from the Client can then be received. The information
 * from the client include the message and sender's number
 * <b>Condition for successful Transaction</b><br>
1.	The SMS is from the phone number used for the registration </b><br>
2.	The PIN number provided is correct</b><br>
3.	The amount of money in the customer’s account is enough</b><br>

 * <br><br>
 *

 * </p>
 *
 *
 *This provides the information on the developers of the software.
DCIT307 MINI-PROJECT DISTANCE EDUCATION FIRST SEMESTER 2023 
* is project was done by one student 
* Ruth Mawutor Konotey 10913771
 */


public class Server implements ActionListener
{

/**
 * Holds the path of the file ip in memory
 */
File ipCheck;
/**
 * Holds the path of the user file in memory
 */
File userDirectory;;
/**
 * writes into the file ip
 */
FileWriter ipWrite;
/**
 * stores the value of the port number given by the user before writing into file
 */
String ip;

/**
 * Object that serves as the server interface
 */
ServerInterface inter;

/**
 * Stores the host address to be accessed by other classes.
 */
static String host;

/**
 * stores the port number which is read from the file ip to connect to the server which can be accessed by other class
 */
static int port;

/**
 * Mulit-threaded server, accepts multiple messages
 */
ListenServer listen;
/**
 * Object of the class help
 */
Help f2;


/**
 * Constructor of server
 */
    public Server ()  {

        inter=new ServerInterface();
        inter.setVisible(true);
//stores the path of the file to check for ip
        ipCheck=new File("ipCheck/ip");

    //condition for if file exist
        if(ipCheck.isFile()){

      		try{
     			FileReader read=new FileReader(ipCheck);
      			BufferedReader buffreader=new BufferedReader(read);
                ip=buffreader.readLine();
   	  			buffreader.close();

                port=Integer.parseInt(ip);
      		}catch(Exception e){
    	    }

       //implement the listen server function to handle a client
    	listenServer();
        }
        else {
        //implement the function that let the administrator input port number
        ipConnect();
        
        }

/**
 * action listenteners added to the objects from the interface
 */
        inter.portNumber.addActionListener(this);
        inter.about.addActionListener(this);
        inter.help.addActionListener(this);
        inter.clear.addActionListener(this);

        //instances of the help created
        f2=new Help();
    }  // end constructor





/**
 * is the main function that is called when the application starts
 * @param args the command line arguments
 */

    public static void main ( String [ ] args )  {

        new Server ();

    }  // end main



/**
 * function that the Server calls to listen to client
 */

  public void listenServer()  {
            listen = new ListenServer ( this );
            listen.start ();
            
        }
/**
 *  implementaion of ActionListener for all the action performed from the objects at the server interface
 *
 * @param e 
 */
    public void actionPerformed(ActionEvent e) {
    /*
     * Conditions to select the button clicked
     */
        if(e.getSource()==inter.portNumber){
            ipConnect();
        }

        else if(e.getSource()==inter.about){
            new About();

        }

        else if(e.getSource()==inter.help){
            f2.showHelp();

        }

        else if(e.getSource()==inter.clear){
            ServerInterface.area.setText("");
        }
    }

    /**
     * function that let the administrator input port number and writes into a file to refer to it any time the application starts
     */

        public void ipConnect() {
         ip=JOptionPane.showInputDialog(null, "Enter the Port Number of the\nserver", "PORT REQUEST",
                JOptionPane.INFORMATION_MESSAGE);
   		if(ip==null){
            return;
        }
         try{
			/**
             * Make Directory
             */
			ipCheck = new File("ipCheck/");
			ipCheck.mkdirs();

			/**
             * Writes the ip into the file
             */
			ipWrite = new FileWriter("ipCheck/ip");
			ipWrite.write(ip+"\n");
			ipWrite.flush();
			ipWrite.close();

    if(ipCheck.exists()){
      		try{
                ipCheck = new File("ipCheck/ip");
     			FileReader read=new FileReader(ipCheck);
      			BufferedReader buffreader=new BufferedReader(read);
                ip=buffreader.readLine();
   	  			buffreader.close();

                port=Integer.parseInt(ip);
      		}catch(Exception e){
    	    }

  }
		}catch(Exception e){}

         listenServer();
    }


}
