package server;


import javax.swing.*;

/**
 *This provides the information on the developers of the software.
DCIT307 MINI-PROJECT DISTANCE EDUCATION FIRST SEMESTER 2023 
* is project was done by one student 
* Ruth Mawutor Konotey 10913771
 */
class About {
/**
 * Constructor of About
 */
    public About() {
       
   JOptionPane.showMessageDialog(null,
           "FADISOFT is SMS-based Utility Payment System.\n"
          +"It allows customers of utility companies to\n"
          +"pay and request for their bills using SMS. \n" 
          +"It was developed by 2 computer engineering\n" +
           "students from University of Ghana as their final\n" +
           "year project. We hope you will enjoy it.\n" +
           "Thank you for choosing SUPS.\n\n" +
           "\t DEVELOPERS\n" +
           "\t-------------------\n" +
           " Ruth Mawutor Konotey\n" +
           "ID  10913771\n\n\n" +
           "\t SUPERVISOR \n" +
           "\t---------------------\n" +
           "Dr Mark Atta Mensah (Lecturer)\n" +
           "\n",
           "ABOUT SUPS", JOptionPane.INFORMATION_MESSAGE,
           new ImageIcon("src/resource/fadisicon.png"));

    }

}
