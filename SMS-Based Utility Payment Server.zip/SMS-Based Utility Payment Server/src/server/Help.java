package server;


import javax.swing.*;

/**
 *This class pops up a help menu that that shows the user how to use the software.
 *
 *This provides the information on the developers of the software.
DCIT307 MINI-PROJECT DISTANCE EDUCATION FIRST SEMESTER 2023 
* is project was done by one student 
* Ruth Mawutor Konotey 10913771
 */
class Help extends JDialog{

    JTextArea area;
    JPanel mainPanel;
  
    String msg;
/**
 * Constructor of help
 */
    public Help() {

        setDefaultCloseOperation(JDialog.HIDE_ON_CLOSE);
        setLocation(300,100);


        setSize(420,600);
        setResizable(false);

        

        mainPanel=new JPanel();
        mainPanel.setSize(400,600);


        area=new JTextArea();
        area.setSize(400,600);

        help();
        area.setAutoscrolls(true);
        area.setEditable(false);
        mainPanel.add(area);

        setContentPane(mainPanel);

    }
/**
 * this function displays the help option
 */
    private void help() {

     msg="\t\tHOW TO USE SUPS\n\n" +
         "\tAt Server Application\n\t----------------------------\n" +
         "+ Install and start the SUPS server application.\n"+
         "+ A dialogue box appears which request you to enter a port number on\n   first start of application.\n" +
         "+ Enter the port number and press enter or click OK\n" +
         "+ The server displays server listening on the port number entered.\n" +
         "+ One can clear the text area if full by clicking File=>Clear Text Area.\n" +
         " \n" +
         "\tAt Client Application\n\t---------------------------\n" +
         "+ Install and start the client application\n" +
         "+ The first time the client is run, it requests for a port number.\n" +
         "+ If port number is wrong, it throws an error message and gives you the\n   chance to enter the port number again.\n" +
         "+ If the port number is finds the server, it starts the client application\n   by connecting to the server.\n" +
         "+ The interface has a which shows the activities of the server.\n" +
          "+ \n";


    area.append(msg);
    }
/**
 * This method shows the help option
 */
    public void showHelp(){

        this.setAlwaysOnTop(true);
        this.setVisible(true);
    }
}
