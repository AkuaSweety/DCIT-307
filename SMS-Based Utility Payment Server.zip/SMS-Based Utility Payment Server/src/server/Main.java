package server;

/**
 *
 *This is the main class that has the main method
 *
 *This provides the information on the developers of the software.
DCIT307 MINI-PROJECT DISTANCE EDUCATION FIRST SEMESTER 2023 
* is project was done by one student 
* Ruth Mawutor Konotey 10913771
 */
public class Main {

    /**
     * the main method that is called to run the application
     * @param args the command line arguments
     */
   // public static void main(String[] args) {

         //   new Server();
  //  }

}
