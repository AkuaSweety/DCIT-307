package server;

import  javax.swing.*;
import  javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;




/**
 * This is the interface of the Server. It provides the object for the user to 
 * Change Port Number,  Clear
 * Text Area, Exit Server , How to Use SUPS and About SUPS.
 *
 *This provides the information on the developers of the software.
DCIT307 MINI-PROJECT DISTANCE EDUCATION FIRST SEMESTER 2023 
* is project was done by one student 
* Ruth Mawutor Konotey 10913771
 */




public class ServerInterface extends  JFrame {

    
    public ServerInterface() {
        initComponents();
    }

    /**
     * This method is called from within the constructor
     */
    @SuppressWarnings("unchecked")

    private void initComponents() {

         GridBagConstraints gridBagConstraints;

        jPanel1 = new  JPanel();
        jPanel2 = new  JPanel();
        jScrollPane1 = new  JScrollPane();
        area = new  JTextArea();
        jToolBar1 = new  JToolBar();
        jMenuBar1 = new  JMenuBar();
        fileMenu = new  JMenu();
        portNumber = new  JMenuItem();
        exit = new  JMenuItem();
        jMenu2 = new  JMenu();
        help = new  JMenuItem();
        about = new  JMenuItem();
        clear=new  JMenuItem ();
        icon=new  JLabel(new  ImageIcon("src/resource/fadisicon.png"));

        setDefaultCloseOperation( WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("SMS-Based Utility Server");
        setMinimumSize(new  Dimension(600, 700));
        getContentPane().setLayout(new  GridBagLayout());

        jPanel1.setLayout(new  GridBagLayout());

        jPanel2.setBorder( BorderFactory.createBevelBorder( BevelBorder.RAISED));

        area.setColumns(20);
        area.setEditable(false);
        area.setRows(5);
        area.setToolTipText("Activities of server");
        area.setDisabledTextColor(new  Color(255, 255, 255));
        area.setAutoscrolls(true);
        jScrollPane1.setViewportView(area);

         GroupLayout jPanel2Layout = new  GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup( GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1,  GroupLayout.DEFAULT_SIZE, 538, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup( GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1,  GroupLayout.Alignment.TRAILING,  GroupLayout.DEFAULT_SIZE, 486, Short.MAX_VALUE)
        );

        gridBagConstraints = new  GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.fill =  GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 20.0;
        jPanel1.add(jPanel2, gridBagConstraints);

        gridBagConstraints = new  GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill =  GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        getContentPane().add(jPanel1, gridBagConstraints);

        jToolBar1.setBorder( BorderFactory.createLineBorder(new  Color(0, 0, 0)));
        jToolBar1.setRollover(true);

        jToolBar1.addSeparator();
        
        jToolBar1.add(icon);


        jToolBar1.addSeparator();
        jToolBar1.addSeparator();
        
               
        

        gridBagConstraints = new  GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill =  GridBagConstraints.BOTH;
        gridBagConstraints.weighty = 1.0;
        getContentPane().add(jToolBar1, gridBagConstraints);

        fileMenu.setText("File");

        
        portNumber.setText("Change Port Number");
        fileMenu.add(portNumber);

        clear.setText("Clear Text Area");
        fileMenu.add(clear);



        exit.setAccelerator( KeyStroke.getKeyStroke(  KeyEvent.VK_X,   InputEvent.CTRL_MASK));
        exit.setText("Exit");
        exit.addActionListener(new   ActionListener() {
            public void actionPerformed(  ActionEvent evt) {
                exitActionPerformed(evt);
            }
        });
        fileMenu.add(exit);


        jMenuBar1.add(fileMenu);

        jMenu2.setText("Help");

        help.setAccelerator( KeyStroke.getKeyStroke(  KeyEvent.VK_F2, 0));
        help.setText("How to Use SUPS?");
        jMenu2.add(help);

        about.setAccelerator( KeyStroke.getKeyStroke(  KeyEvent.VK_U,   InputEvent.CTRL_MASK));
        about.setText("About");
        jMenu2.add(about);

        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        pack();
    }

    /**
     * This provides the action performed by the exit menu item
     * @param evt is the action event
     */
    private void exitActionPerformed(  ActionEvent evt) {
        dispose();  
}

    // Variables declaration

    public  JMenuItem about;
    public static  JTextArea area;
    private  JMenuItem exit;
    public  JMenuItem help;
    private  JMenu jMenu2;
    private  JMenuBar jMenuBar1;
    private  JPanel jPanel1;
    private  JPanel jPanel2;
    private  JScrollPane jScrollPane1;
    private  JToolBar jToolBar1;
    private  JMenu fileMenu;
    public   JMenuItem portNumber;
    public   JMenuItem clear;
    public   JLabel icon;
    // End of variables declaration

}
